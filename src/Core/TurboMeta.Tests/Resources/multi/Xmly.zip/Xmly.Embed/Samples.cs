﻿namespace Xmly.Embed
{
    public static class Samples
    {
        public static readonly string Courses = @"

<?xml version=""1.0"" encoding=""utf-16""?>
<Courses xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"">
  <Academy>Coding with Desmond Tutu</Academy>
  <Course Id=""1"">
    <Title>How to get started with MailKit</Title>
    <Duration>4 hours and 42 minutes</Duration>
    <Instructor>Desmond Tutu</Instructor>
    <Price Currency=""DKK"">Free</Price>
  </Course>
  <Course Id=""2"">
    <Title>Dapper with repository in ASP.NET</Title>
    <Duration>4 hours and 30 minutes</Duration>
    <Instructor>Desmond Tutu</Instructor>
    <Price Currency=""EUR"">Free</Price>
  </Course>
  <Course Id=""3"">
    <Title>How to create a WEB API</Title>
    <Duration>4 hours and 38 minutes</Duration>
    <Instructor>Desmond Tutu</Instructor>
    <Price Currency=""USD"">19.95</Price>
  </Course>
</Courses>

";
    }
}