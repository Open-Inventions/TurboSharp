Imports System.Xml.Serialization

<XmlRoot(ElementName:="Price")>
Public Class Price
    <XmlAttribute(AttributeName:="Currency")>
    Public Property Currency As String

    <XmlText>
    Public Property Text As String
End Class