Imports System.Collections.Generic
Imports System.Xml.Serialization

<XmlRoot("Courses")>
Public Class Courses
    <XmlElement(ElementName:="Academy")>
    Public Property Academy As String

    <XmlElement(ElementName:="Course")>
    Public Property CourseList As List(Of Course)

    Public Sub New()
        CourseList = New List(Of Course)()
    End Sub
End Class