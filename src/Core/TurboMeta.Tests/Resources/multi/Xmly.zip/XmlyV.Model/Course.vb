Imports System.Xml.Serialization

<XmlRoot(ElementName:="Course")>
Public Class Course
    <XmlElement(ElementName:="Title")>
    Public Property Title As String

    <XmlElement(ElementName:="Duration")>
    Public Property Duration As String

    <XmlElement(ElementName:="Instructor")>
    Public Property Instructor As String

    <XmlElement(ElementName:="Price")>
    Public Property Price As Price

    <XmlAttribute(AttributeName:="Id")>
    Public Property Id As Integer

    <XmlText>
    Public Property Text As String

    Public Sub New()
        Price = New Price()
    End Sub
End Class