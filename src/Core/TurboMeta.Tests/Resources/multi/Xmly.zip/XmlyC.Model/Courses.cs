﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace XmlyC.Model
{
    [XmlRoot("Courses")]
    public class Courses
    {
        [XmlElement(ElementName = "Academy")] 
        public string Academy { get; set; }

        [XmlElement(ElementName = "Course")] 
        public List<Course> CourseList { get; set; }

        public Courses()
        {
            CourseList = new List<Course>();
        }
    }
}