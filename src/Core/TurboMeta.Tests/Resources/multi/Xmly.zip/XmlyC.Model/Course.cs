﻿using System.Xml.Serialization;

namespace XmlyC.Model
{
    [XmlRoot(ElementName = "Course")]
    public class Course
    {
        [XmlElement(ElementName = "Title")]
        public string Title { get; set; }

        [XmlElement(ElementName = "Duration")]
        public string Duration { get; set; }

        [XmlElement(ElementName = "Instructor")]
        public string Instructor { get; set; }

        [XmlElement(ElementName = "Price")]
        public Price Price { get; set; }

        [XmlAttribute(AttributeName = "Id")]
        public int Id { get; set; }

        [XmlText]
        public string Text { get; set; }

        public Course()
        {
            Price = new Price();
        }
    }
}