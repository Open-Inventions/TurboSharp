﻿using System.Xml.Serialization;

namespace XmlyC.Model
{
    [XmlRoot(ElementName = "Price")]
    public class Price
    {
        [XmlAttribute(AttributeName = "Currency")]
        public string Currency { get; set; }

        [XmlText]
        public string Text { get; set; }
    }
}