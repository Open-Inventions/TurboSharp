Imports System

Module Program
    Sub Main()
        Console.WriteLine("Hello from VB !")
    End Sub
End Module
